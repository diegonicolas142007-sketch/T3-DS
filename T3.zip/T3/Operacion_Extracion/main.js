// IMPORTACIONES


import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);

const camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
);

camera.position.set(0, 1.7, 10);
scene.add(camera);

const renderer = new THREE.WebGLRenderer({ antialias: true });

renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

document.body.appendChild(renderer.domElement);

const controls = new PointerLockControls(camera, renderer.domElement);
const loader = new GLTFLoader();
const clock = new THREE.Clock();

// 1ILUMINACIÓN


const ambientLight = new THREE.HemisphereLight(
    0xffffff,
    0x444444,
    2
);

scene.add(ambientLight);

const sunlight = new THREE.DirectionalLight(0xffffff, 2);

sunlight.position.set(10, 20, 10);
sunlight.castShadow = true;

scene.add(sunlight);

//SUELO Y CARRETERA


// Suelo
const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(100, 100),
    new THREE.MeshStandardMaterial({ color: 0x555555 })
);

floor.rotation.x = -Math.PI / 2;
floor.receiveShadow = true;

scene.add(floor);

// Carretera
const road = new THREE.Mesh(
    new THREE.PlaneGeometry(12, 90),
    new THREE.MeshStandardMaterial({ color: 0x292929 })
);

road.rotation.x = -Math.PI / 2;
road.position.set(0, 0.02, -15);

scene.add(road);

//SISTEMA DE COLISIONES


const colliders = [];
const playerRadius = 0.55;

function addCollider(x, z, width, depth) {
    colliders.push({
        minX: x - width / 2,
        maxX: x + width / 2,
        minZ: z - depth / 2,
        maxZ: z + depth / 2
    });
}

function checkCollision(x, z) {
    for (const collider of colliders) {
        const collisionX =
            x + playerRadius > collider.minX &&
            x - playerRadius < collider.maxX;

        const collisionZ =
            z + playerRadius > collider.minZ &&
            z - playerRadius < collider.maxZ;

        if (collisionX && collisionZ) {
            return true;
        }
    }

    return false;
}

//EDIFICIOS

function createBuilding(x, z, width, height, depth, color) {
    const building = new THREE.Mesh(
        new THREE.BoxGeometry(width, height, depth),
        new THREE.MeshStandardMaterial({ color })
    );

    building.position.set(x, height / 2, z);
    building.castShadow = true;
    building.receiveShadow = true;

    scene.add(building);
    addCollider(x, z, width, depth);
}

createBuilding(-12, -8, 10, 12, 12, 0x777777);
createBuilding(12, -15, 10, 15, 12, 0x666666);
createBuilding(-13, -30, 12, 10, 12, 0x888888);
createBuilding(13, -38, 12, 13, 12, 0x555555);
createBuilding(-12, -52, 10, 14, 12, 0x666666);

//OBSTÁCULOS
function createObstacle(x, z, color) {
    const obstacle = new THREE.Mesh(
        new THREE.BoxGeometry(2, 1.5, 2),
        new THREE.MeshStandardMaterial({ color })
    );

    obstacle.position.set(x, 0.75, z);
    obstacle.castShadow = true;
    obstacle.receiveShadow = true;

    scene.add(obstacle);
    addCollider(x, z, 2, 2);
}

createObstacle(-4, -8, 0x795548);
createObstacle(4, -17, 0x8d6e63);
createObstacle(-3, -27, 0x795548);
createObstacle(4, -37, 0x8d6e63);

//ZONA DE EXTRACCIÓN

const extraction = new THREE.Mesh(
    new THREE.CylinderGeometry(4, 4, 0.2, 32),
    new THREE.MeshStandardMaterial({
        color: 0x00cc66,
        emissive: 0x003311
    })
);

extraction.position.set(0, 0.1, -60);
scene.add(extraction);

const marker = new THREE.Mesh(
    new THREE.BoxGeometry(4, 3, 0.3),
    new THREE.MeshStandardMaterial({ color: 0x00aa55 })
);

marker.position.set(0, 2, -60);
scene.add(marker);

// ARMAS 3D Y MUNICIÓN

const weaponHolder = new THREE.Group();

weaponHolder.position.set(0.35, -0.30, -0.65);
camera.add(weaponHolder);

const weaponModels = {
    pistol: null,
    rifle: null
};

const ammunition = {
    pistol: 12,
    rifle: 30
};

const maxAmmunition = {
    pistol: 24,
    rifle: 60
};

let currentWeapon = 'pistol';

function loadWeapon(path, weaponName) {
    loader.load(
        path,
        function(gltf) {
            const model = gltf.scene;

            const box = new THREE.Box3().setFromObject(model);
            const size = new THREE.Vector3();
            const center = new THREE.Vector3();

            box.getSize(size);
            box.getCenter(center);

            const targetSize = weaponName === 'pistol' ? 0.48 : 0.85;
            const maxDimension = Math.max(size.x, size.y, size.z);

            if (maxDimension === 0) {
                console.error('El modelo no tiene dimensiones:', path);
                return;
            }

            const scale = targetSize / maxDimension;

            model.scale.setScalar(scale);

            model.position.set(
                -center.x * scale,
                -center.y * scale,
                -center.z * scale
            );

            const weaponGroup = new THREE.Group();

            weaponGroup.add(model);
            weaponGroup.rotation.set(0, Math.PI / 2, 0);
            weaponGroup.visible = false;

            weaponHolder.add(weaponGroup);
            weaponModels[weaponName] = weaponGroup;

            if (currentWeapon === weaponName) {
                weaponGroup.visible = true;
            }

            console.log('Arma cargada:', weaponName);
        },
        undefined,
        function(error) {
            console.error('Error al cargar:', path, error);
        }
    );
}

function selectWeapon(weaponName) {
    currentWeapon = weaponName;

    if (weaponModels.pistol) {
        weaponModels.pistol.visible = false;
    }

    if (weaponModels.rifle) {
        weaponModels.rifle.visible = false;
    }

    if (weaponModels[weaponName]) {
        weaponModels[weaponName].visible = true;
    }

    updateHUD();
}

loadWeapon('./models/weapons/pistola.glb', 'pistol');
loadWeapon('./models/weapons/rifle.glb', 'rifle');

//VIDA E INTERFAZ HUD

let playerHealth = 100;
let gameOver = false;

const healthElement = document.getElementById('health');
const weaponElement = document.getElementById('weapon');
const ammoElement = document.getElementById('ammo');

function updateHUD() {
    healthElement.textContent = playerHealth;

    if (currentWeapon === 'pistol') {
        weaponElement.textContent = 'Pistola';
        ammoElement.textContent = ammunition.pistol;
    } else {
        weaponElement.textContent = 'Rifle';
        ammoElement.textContent = ammunition.rifle;
    }
}

updateHUD();

// PUNTERO CENTRAL

const crosshair = document.createElement('div');

crosshair.textContent = '+';
crosshair.style.position = 'absolute';
crosshair.style.left = '50%';
crosshair.style.top = '50%';
crosshair.style.transform = 'translate(-50%, -50%)';
crosshair.style.color = 'white';
crosshair.style.fontSize = '28px';
crosshair.style.fontWeight = 'bold';
crosshair.style.pointerEvents = 'none';
crosshair.style.display = 'none';
crosshair.style.zIndex = '6';

document.body.appendChild(crosshair);

//11. ZOMBIS 3D E CONFIGURACIÓN DE IA

const zombieLoader = new GLTFLoader();
const zombies = [];

const zombiePositions = [
    { x: -2, z: -12 },
    { x: 2, z: -23 },
    { x: -2, z: -34 },
    { x: 2, z: -45 },
    { x: 0, z: -55 }
];

const detectionRange = 14;
const zombieSpeed = 1.5;
const zombieAttackRange = 1.5;
const zombieDamage = 10;

function createZombie(modelOriginal, x, z) {
    const model = modelOriginal.clone(true);

    const box = new THREE.Box3().setFromObject(model);
    const size = new THREE.Vector3();
    const center = new THREE.Vector3();

    box.getSize(size);
    box.getCenter(center);

    const targetHeight = 1.8;

    if (size.y === 0) {
        console.error('El modelo del zombi no tiene altura');
        return;
    }

    const scale = targetHeight / size.y;

    model.scale.setScalar(scale);

    model.position.set(
        -center.x * scale,
        -box.min.y * scale,
        -center.z * scale
    );

    model.traverse(function(object) {
        if (object.isMesh) {
            object.castShadow = true;
            object.receiveShadow = true;
        }
    });

    const zombieGroup = new THREE.Group();

    zombieGroup.add(model);
    zombieGroup.position.set(x, 0, z);

    scene.add(zombieGroup);

    const zombie = {
        group: zombieGroup,
        health: 2,
        alive: true,
        attackTimer: 0,
        originalX: x,
        originalZ: z
    };

    zombieGroup.traverse(function(object) {
        object.userData.zombie = zombie;
    });

    zombies.push(zombie);

    console.log('Zombi creado en:', x, z);
}

zombieLoader.load(
    './models/zombies/zombie.glb',
    function(gltf) {
        const originalModel = gltf.scene;

        for (const position of zombiePositions) {
            createZombie(
                originalModel,
                position.x,
                position.z
            );
        }

        console.log('Todos los zombis han sido cargados');
    },
    undefined,
    function(error) {
        console.error('Error al cargar zombie.glb:', error);
    }
);

//12. CAJA DE MUNICIÓN 3D

const ammoBox = new THREE.Group();

const ammoMaterial = new THREE.MeshStandardMaterial({
    color: 0x385b36,
    roughness: 0.8
});

const yellowMaterial = new THREE.MeshStandardMaterial({
    color: 0xffcc00,
    emissive: 0x332200
});

// Cuerpo
const ammoBody = new THREE.Mesh(
    new THREE.BoxGeometry(1.2, 0.8, 0.8),
    ammoMaterial
);

ammoBody.position.y = 0.4;
ammoBody.castShadow = true;
ammoBox.add(ammoBody);

// Tapa
const ammoLid = new THREE.Mesh(
    new THREE.BoxGeometry(1.25, 0.12, 0.85),
    new THREE.MeshStandardMaterial({ color: 0x263e25 })
);

ammoLid.position.y = 0.86;
ammoLid.castShadow = true;
ammoBox.add(ammoLid);

// Franja amarilla
const yellowStripe = new THREE.Mesh(
    new THREE.BoxGeometry(0.12, 0.65, 0.03),
    yellowMaterial
);

yellowStripe.position.set(0, 0.43, 0.415);
ammoBox.add(yellowStripe);

// Símbolo
const ammoSymbol = new THREE.Mesh(
    new THREE.BoxGeometry(0.38, 0.08, 0.04),
    yellowMaterial
);

ammoSymbol.position.set(0, 0.45, 0.44);
ammoBox.add(ammoSymbol);

// Ubicación
ammoBox.position.set(3, 0, -30);
scene.add(ammoBox);

let ammoBoxCollected = false;

// Mensaje de recogida
const ammoNotice = document.createElement('div');

ammoNotice.style.position = 'absolute';
ammoNotice.style.bottom = '90px';
ammoNotice.style.left = '50%';
ammoNotice.style.transform = 'translateX(-50%)';
ammoNotice.style.color = '#ffcc00';
ammoNotice.style.fontSize = '20px';
ammoNotice.style.fontWeight = 'bold';
ammoNotice.style.textShadow = '2px 2px 4px black';
ammoNotice.style.display = 'none';
ammoNotice.style.zIndex = '10';

document.body.appendChild(ammoNotice);

function updateAmmoPickup() {
    if (ammoBoxCollected || !controls.isLocked || gameOver) {
        return;
    }

    const distance = camera.position.distanceTo(
        new THREE.Vector3(
            ammoBox.position.x,
            camera.position.y,
            ammoBox.position.z
        )
    );

    if (distance <= 2) {
        const hasSpace =
            ammunition.pistol < maxAmmunition.pistol ||
            ammunition.rifle < maxAmmunition.rifle;

        if (!hasSpace) {
            return;
        }

        ammunition.pistol = Math.min(
            ammunition.pistol + 6,
            maxAmmunition.pistol
        );

        ammunition.rifle = Math.min(
            ammunition.rifle + 15,
            maxAmmunition.rifle
        );

        ammoBoxCollected = true;
        scene.remove(ammoBox);

        updateHUD();

        ammoNotice.textContent =
            '¡MUNICIÓN RECOGIDA! +6 PISTOLA / +15 RIFLE';

        ammoNotice.style.display = 'block';

        setTimeout(function() {
            ammoNotice.style.display = 'none';
        }, 2500);

        console.log('Caja de munición recogida');
    }
}

// 13. EFECTO VISUAL DEL DISPARO

function createShotEffect(direction, hitPoint) {
    const start = camera.position.clone().add(
        direction.clone().multiplyScalar(1.2)
    );

    const end = hitPoint
        ? hitPoint.clone()
        : start.clone().add(
            direction.clone().multiplyScalar(20)
        );

    // Línea amarilla del disparo
    const geometry = new THREE.BufferGeometry().setFromPoints([
        start,
        end
    ]);

    const material = new THREE.LineBasicMaterial({
        color: 0xffff00,
        transparent: true,
        opacity: 1,
        depthTest: false,
        depthWrite: false
    });

    const tracer = new THREE.Line(geometry, material);

    tracer.renderOrder = 999;
    scene.add(tracer);

    // Destello inicial
    const flashGeometry = new THREE.SphereGeometry(0.07, 8, 8);

    const flashMaterial = new THREE.MeshBasicMaterial({
        color: 0xffff00,
        depthTest: false
    });

    const flash = new THREE.Mesh(
        flashGeometry,
        flashMaterial
    );

    flash.position.copy(start);
    flash.renderOrder = 1000;

    scene.add(flash);

    // Limpieza del efecto
    setTimeout(function() {
        scene.remove(tracer);
        scene.remove(flash);

        geometry.dispose();
        material.dispose();

        flashGeometry.dispose();
        flashMaterial.dispose();
    }, 180);
}

//DISPAROS Y RAYCASTING


const raycaster = new THREE.Raycaster();

function shoot() {
    if (!controls.isLocked || gameOver) {
        return;
    }

    if (ammunition[currentWeapon] <= 0) {
        console.log('No tienes munición');
        return;
    }

    // Consumir una bala
    ammunition[currentWeapon]--;
    updateHUD();

    // Raycasting desde el centro de la pantalla
    raycaster.setFromCamera(
        new THREE.Vector2(0, 0),
        camera
    );

    const objectsToCheck = scene.children.filter(
        object => object !== camera
    );

    const intersections = raycaster.intersectObjects(
        objectsToCheck,
        true
    );

    let hitPoint = null;

    if (intersections.length > 0) {
        const hitObject = intersections[0].object;

        hitPoint = intersections[0].point.clone();

        let currentObject = hitObject;
        let hitZombie = null;

        while (currentObject) {
            if (currentObject.userData.zombie) {
                hitZombie = currentObject.userData.zombie;
                break;
            }

            currentObject = currentObject.parent;
        }

        if (hitZombie && hitZombie.alive) {
            hitZombie.health--;

            console.log(
                'Zombi alcanzado. Vida restante:',
                hitZombie.health
            );

            if (hitZombie.health <= 0) {
                hitZombie.alive = false;
                console.log('¡Zombi eliminado!');
            }
        }
    }

    // Mostrar efecto del disparo
    const shotDirection = new THREE.Vector3();

    camera.getWorldDirection(shotDirection);

    createShotEffect(shotDirection, hitPoint);
}

document.addEventListener('mousedown', function(event) {
    if (event.button === 0) {
        shoot();
    }
});

//INTELIGENCIA ARTIFICIAL DE LOS ZOMBIS

function updateZombies(delta) {
    if (!controls.isLocked || gameOver) {
        return;
    }

    for (const zombie of zombies) {
        if (!zombie.alive) {
            continue;
        }

        const zombiePosition = zombie.group.position;

        const distanceX = camera.position.x - zombiePosition.x;
        const distanceZ = camera.position.z - zombiePosition.z;

        const distance = Math.sqrt(
            distanceX * distanceX +
            distanceZ * distanceZ
        );

        // Activar persecución dentro del rango
        if (distance > detectionRange) {
            continue;
        }

        // Ataque al jugador
        if (distance <= zombieAttackRange) {
            zombie.attackTimer -= delta;

            if (zombie.attackTimer <= 0) {
                playerHealth -= zombieDamage;

                if (playerHealth < 0) {
                    playerHealth = 0;
                }

                zombie.attackTimer = 1.2;

                updateHUD();

                console.log(
                    '¡El zombi te atacó! Vida:',
                    playerHealth
                );

                if (playerHealth <= 0) {
                    finishGame();
                    return;
                }
            }
        } else {
            // Perseguir al jugador
            zombie.attackTimer = 0;

            const direction = new THREE.Vector3(
                distanceX,
                0,
                distanceZ
            );

            direction.normalize();

            zombie.group.position.x +=
                direction.x * zombieSpeed * delta;

            zombie.group.position.z +=
                direction.z * zombieSpeed * delta;

            zombie.group.rotation.y = Math.atan2(
                direction.x,
                direction.z
            );
        }
    }
}

//MENÚ, PAUSA Y REFERENCIAS DE INTERFAZ

const menu = document.getElementById('menu');
const startButton = document.getElementById('startButton');
const hud = document.getElementById('hud');

function resetKeys() {
    keys.w = false;
    keys.a = false;
    keys.s = false;
    keys.d = false;
}

startButton.addEventListener('click', function() {
    if (gameOver) {
        window.location.reload();
        return;
    }

    controls.lock();
});

controls.addEventListener('lock', function() {
    menu.style.display = 'none';
    hud.style.display = 'block';
    crosshair.style.display = 'block';

    resetKeys();
});

controls.addEventListener('unlock', function() {
    resetKeys();

    crosshair.style.display = 'none';

    if (!gameOver) {
        menu.style.display = 'flex';
        hud.style.display = 'block';

        startButton.textContent = 'CONTINUAR MISIÓN';
    }
});

window.addEventListener('blur', function() {
    resetKeys();
});

//GAME OVER

function finishGame() {
    if (gameOver) {
        return;
    }

    gameOver = true;

    controls.unlock();

    menu.style.display = 'flex';

    menu.querySelector('h1').textContent = 'GAME OVER';

    menu.querySelector('p').textContent =
        'Has sido eliminado por los zombis.';

    startButton.textContent = 'REINTENTAR MISIÓN';

    console.log('GAME OVER');
}

//VICTORIA Y EXTRACCIÓN

function winGame() {
    if (gameOver) {
        return;
    }

    gameOver = true;

    controls.unlock();

    menu.style.display = 'flex';

    menu.querySelector('h1').textContent =
        '¡MISIÓN COMPLETADA!';

    menu.querySelector('p').textContent =
        'Has sobrevivido y llegado a la zona de extracción.';

    startButton.textContent = 'VOLVER A JUGAR';

    console.log('¡VICTORIA! Misión completada.');
}

function checkExtraction() {
    if (gameOver) {
        return;
    }

    const distance = Math.sqrt(
        Math.pow(camera.position.x - extraction.position.x, 2) +
        Math.pow(camera.position.z - extraction.position.z, 2)
    );

    if (distance <= 4) {
        winGame();
    }
}

//CONTROLES DEL JUGADOR


const keys = {
    w: false,
    a: false,
    s: false,
    d: false
};

document.addEventListener('keydown', function(event) {
    const key = event.key.toLowerCase();

    if (key in keys) {
        keys[key] = true;
    }

    // Selección de armas
    if (controls.isLocked && !event.repeat) {
        if (key === '1') {
            selectWeapon('pistol');
        }

        if (key === '2') {
            selectWeapon('rifle');
        }
    }
});

document.addEventListener('keyup', function(event) {
    const key = event.key.toLowerCase();

    if (key in keys) {
        keys[key] = false;
    }
});

//MOVIMIENTO FPS Y COLISIONES
const speed = 8;

const forward = new THREE.Vector3();
const right = new THREE.Vector3();
const up = new THREE.Vector3(0, 1, 0);
const movement = new THREE.Vector3();

function updateMovement(delta) {
    let forwardAmount = 0;
    let rightAmount = 0;

    if (keys.w) forwardAmount += 1;
    if (keys.s) forwardAmount -= 1;
    if (keys.d) rightAmount += 1;
    if (keys.a) rightAmount -= 1;

    if (forwardAmount === 0 && rightAmount === 0) {
        return;
    }

    controls.getDirection(forward);

    forward.y = 0;
    forward.normalize();

    right.crossVectors(forward, up).normalize();

    movement.set(0, 0, 0);

    movement.addScaledVector(forward, forwardAmount);
    movement.addScaledVector(right, rightAmount);

    movement.normalize();
    movement.multiplyScalar(speed * delta);

    // Movimiento horizontal
    const nextX = camera.position.x + movement.x;

    if (
        nextX >= -20 &&
        nextX <= 20 &&
        !checkCollision(nextX, camera.position.z)
    ) {
        camera.position.x = nextX;
    }

    // Movimiento vertical 
    const nextZ = camera.position.z + movement.z;

    if (
        nextZ >= -62 &&
        nextZ <= 15 &&
        !checkCollision(camera.position.x, nextZ)
    ) {
        camera.position.z = nextZ;
    }

    camera.position.y = 1.7;
}


   // BUCLE PRINCIPAL DEL JUEGO


function animate() {
    requestAnimationFrame(animate);

    const delta = Math.min(clock.getDelta(), 0.05);

    if (controls.isLocked && !gameOver) {
        updateMovement(delta);
        updateZombies(delta);
        updateAmmoPickup();
        checkExtraction();
    }

    renderer.render(scene, camera);
}

animate();

// AJUSTE RESPONSIVE DE LA VENTANA


window.addEventListener('resize', function() {
    camera.aspect = window.innerWidth / window.innerHeight;

    camera.updateProjectionMatrix();

    renderer.setSize(
        window.innerWidth,
        window.innerHeight
    );
});
